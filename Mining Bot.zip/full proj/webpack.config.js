module.exports = function (webpackEnv) {
  return {
    resolve: {
      fallback: {
        // Here paste
      },
    },
  };
};
