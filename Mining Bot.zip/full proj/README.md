# Install Guide

Use NPM for install packages
And use node.js v19 or later

npm install --legacy-peer-deps
npm start
