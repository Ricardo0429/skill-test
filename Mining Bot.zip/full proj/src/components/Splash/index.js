export { default } from "./Splash";
