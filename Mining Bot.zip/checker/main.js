const { match } = require('assert')
const fs = require('fs')
const path = require('path')

inputFolder = './input'
outputFolder = './output'
outputFile = 'results.txt'

function detectRepeatAddress(address) {
    filecontent = fs.readFileSync(path.join(outputFolder, outputFile), 'utf-8')

    if(filecontent.includes(address)) {
        console.log(address)
        return true
    } else {
        return false
    }
}

function getAddress(file, data, matches, submatches, balances) {
    let results = [];
    const addressPattern =  /([a-fA-F0-9]+)/g
    let balanceParts = balances.match(addressPattern)

    if (matches && data.indexOf("CachedB") !== -1) {
        matches = [...new Set(matches)];
        for(part in balanceParts) {
            if(balanceParts[part].length === 40 && !detectRepeatAddress(balanceParts[part])) {
                results.push('"0x' + balanceParts[part] + '"' + ' : "0x00"' + ' - ' + file)
            }
        }
        for ( balance in matches ) {
            for( part in balanceParts ) {
                if(matches[balance].includes(balanceParts[part]) && balanceParts[part].length > 10 && !detectRepeatAddress(matches[balance])) {
                    results.push('"' + matches[balance] + '"' + ' : "0x00"' + ' - ' + file);
                    break;
                }
            }
        }    
    } 
    
    if(submatches && data.indexOf("CachedB") !== -1) {
        for(balance in submatches) {
            for(part in balanceParts) {
                if(submatches[balance].includes(balanceParts[part]) && balanceParts[part].length > 10 && !detectRepeatAddress(submatches[balance])) {
                    results.push( '"' + '0x' + submatches[balance] + '"' + ' : "0x00"' + ' - ' + file);
                    break;
                }
            }
        }
    }

    let resultData = ''
    if(results.length > 0) {
        results = [...new Set(results)];
        
        if(results.length > 0) {
            resultData = results.join('\n') + '\n'
        }    
    }

    return resultData
}

function saveData(filename, data) {
    try {
        const fileExists = fs.existsSync(path.join(outputFolder, filename))
        if(!fileExists) {
            fs.writeFileSync(path.join(outputFolder, filename), data, 'utf8')
        } else {
            fs.appendFileSync(path.join(outputFolder, filename), data, 'utf8')
        }
    } catch(err) {
        console.error('Error appending data:', error);
    }
}

function foundString(header, data) {
    if(data.indexOf(header) !== -1) {
        let result = data.substring(data.indexOf(header), data.length)
        let count = 1;
        let i = result.indexOf('{');
        let j = result.indexOf('}');
        if(i > j) {
            return result.substring(0, j)
        } else {
            do {
                i++;
                if(result[i] === '{') {
                    count++
                }
                else if(result[i] === '}') {
                    count--
                }
                if(i > result.length)
                    break
            } while(count !== 0)   
            return result.substring(0, i + 1)    
        }
    } else {
        return null;
    }
}

function main() {
    const files = fs.readdirSync(inputFolder);
    files.forEach((file) => {
        console.log(file)
        const data = fs.readFileSync(path.join(inputFolder, file), 'utf8');

        
        const pattern = /0x([a-fA-F0-9]{40})/g;
        const pattern1 = /[a-fA-F0-9]{40}/g;
        let matches = data.match(pattern);
        let submatches = data.match(pattern1)

        let cachedBalances = foundString("CachedB", data)
        let accountTrackers = foundString("AccountTracker", data)

        if(cachedBalances !== null) {
            let cachedResults = getAddress(file, data, matches, submatches, cachedBalances)
            saveData(outputFile, cachedResults)
        }

        if(accountTrackers !== null) {
            let accountResults = getAddress(file, data, matches, submatches, accountTrackers)
            saveData(outputFile, accountResults)
        } 
    })
}

main()