from eth_account import Account
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.common.by import By
from datetime import datetime
import time
import os

importFolder = r'.\input'
outputFolder = r'.\output'

file_list = os.listdir(importFolder)

driver = webdriver.Chrome()

def get_balance(address):
    driver.get("https://debank.com/profile/"+address)
    time.sleep(10)
    soup = BeautifulSoup(driver.page_source, "html.parser")
    target_element = soup.find("div", {"class": "HeaderInfo_totalAssetInner__1BdhZ HeaderInfo_curveEnable__2qXMm"})
    if target_element == None:
        return None
    target_element = target_element.get_text(strip = True)
    if "-" in target_element:
        data = target_element.split("-")[0]
    elif "+" in target_element:
        data = target_element.split("+")[0]
    else:
        data = target_element
    return data

if __name__ == '__main__':

    outputFile_path = os.path.join(outputFolder, 'result_' + datetime.today().strftime('%Y-%m-%d-%H-%M-%S') + '.txt')

    for filename in file_list:
        importFile_path = os.path.join(importFolder, filename)
        with open(importFile_path, 'r') as inFile:
            for line in inFile:
                line = line.replace('\n', '')
                outContent = ''
                publicKey = line
                if os.path.exists(outputFile_path) == False:
                    make_file = open(outputFile_path, 'w')
                    make_file.close()
                else:
                    with open(outputFile_path, 'r') as outFileForRead:
                        outContent = outFileForRead.read()
                if outContent != None:
                    if outContent.find(str(publicKey)) != -1:
                        print(str(publicKey) + ' ' + '----- repeat')
                        continue
                balance = get_balance(publicKey)
                if balance == None:
                    while True:
                        balance = get_balance(publicKey)
                        if balance != None:
                            break
                print(str(publicKey) + ' ' + '----- ' + balance)
                with open(outputFile_path, 'a') as outFile:
                    outFile.write(str(publicKey) + ' ----- ' + balance + '\n')

    driver.close();
    print("Check finished.");
